arm-none-linux-gnueabi-g++ -o camera camera.cpp main.cpp -static
